En el video menciono que necesitan una compuerta XNOR, pero es un error.
Es una XOR, disculpen por eso, espero que no se confundan.